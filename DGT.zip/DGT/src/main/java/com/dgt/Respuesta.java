/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dgt;



/**
 *
 * @author david
 */
public class Respuesta {
    private String rc;
    private String rd;

    public Respuesta(String rc, String rd) {
        this.rc = rc;
        this.rd = rd;
    }
    

}
