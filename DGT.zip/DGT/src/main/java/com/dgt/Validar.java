/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dgt;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alumno Tarde
 */
public class Validar {
    public List <Pregunta> preguntasAcertadas = new ArrayList<>();
    public List <Pregunta> preguntasErradas = new ArrayList<>();
    int nPreguntas = 10;
    public void Validar(List<Pregunta> lista){
        for(int a = 0;a<nPreguntas;a++){
            
        }
    }
    public void addPreguntasAcertadas(Pregunta p){
        preguntasAcertadas.add(p);
    }
    public void addPreguntasErradas(Pregunta p){
        preguntasErradas.add(p);
    }
    public List<Pregunta> getPreguntasAcertadas() {
        return preguntasAcertadas;
    }

    public List<Pregunta> getPreguntasErradas() {
        return preguntasErradas;
    }
}
